package com.example.guesstheno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int randomno;
    public void guessToast (String str) {

        Toast.makeText(MainActivity.this,str, Toast.LENGTH_SHORT).show();

    }
    public void click(View view) {

        EditText textField = (EditText) findViewById(R.id.edit2);

        int guess = Integer.parseInt(textField.getText().toString());
        Log.i("INFO",textField.getText().toString());

        if (guess < randomno) {
           guessToast("Higher!!");

        }
        else if (guess == randomno) {
            guessToast("Awesome!! Try Again");

            Random rand = new Random();
            randomno = rand.nextInt(20) + 1;

        }
        else {
            guessToast("Lower!!");

        }





    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Random rand = new Random();
        randomno = rand.nextInt(20) + 1;
    }
}
