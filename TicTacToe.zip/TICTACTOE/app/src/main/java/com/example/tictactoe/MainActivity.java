package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.tictactoe.R.drawable.green;
import static java.lang.System.exit;

public class MainActivity extends AppCompatActivity {

    boolean gameActive = true;

    int[] gamestate = {2,2,2,2,2,2,2,2,2};
    int[][] winningpositions = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    //0=green , 1=red

    int activeplayer = 0;

    public void dropIn (View view) {

        ImageView counter = (ImageView) view;

        System.out.println(counter.getTag().toString());

        int tappedcounter = Integer.parseInt(counter.getTag().toString());

        if (gamestate[tappedcounter]==2 && gameActive) {

            gamestate[tappedcounter]=activeplayer;

            counter.setTranslationY(-1200f);

            if (activeplayer == 0) {

                counter.setImageResource(green);

                activeplayer = 1;

            } else {

                counter.setImageResource(R.drawable.red);

                activeplayer = 0;
            }

            counter.animate().translationYBy(1200f).setDuration(200);


            for(int[] winning : winningpositions) {

                if(gamestate[winning[0]] == gamestate[winning[1]] && gamestate[winning[1]]==gamestate[winning[2]] && gamestate[winning[0]]!=2) {

                    gameActive = false;

                    String won = "RED";

                    if(gamestate[winning[0]] == 0) {

                        won = "GREEN";
                    }
                    TextView text = (TextView) findViewById(R.id.textView);

                    text.setText(  won + " HAS" + "\n" +" WON");

                    LinearLayout linear = (LinearLayout) findViewById(R.id.linear);

                    linear.setVisibility(View.VISIBLE);

                     }else {

                    boolean gameIs = true ;

                    for (int counterState : gamestate) {

                        if(counterState ==2) {

                            gameIs = false ;
                        }
                    }

                    if(gameIs) {

                        TextView text = (TextView) findViewById(R.id.textView);

                        text.setText("IT'S DRAW");

                        LinearLayout linear = (LinearLayout) findViewById(R.id.linear);

                        linear.setVisibility(View.VISIBLE);

                    }
                }



                }

            }
        }
        public void playAgain (View view) {

            gameActive = true;

            LinearLayout linear = (LinearLayout) findViewById(R.id.linear);

            linear.setVisibility(View.INVISIBLE);

            int activeplayer = 0;

            for(int i = 0;i<gamestate.length;i++) {

                gamestate[i] = 2;

            }

            GridLayout grid = (GridLayout) findViewById(R.id.grid);

            for(int i =0;i<grid.getChildCount();i++){

                ((ImageView) grid.getChildAt(i)).setImageResource(0);

            }


        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
